using System.Text;
using System.Text.Json;

namespace Amr.Simulator.Map.Navigation;

public sealed record GridMissionSettings(string AmrId, GridCell Start, IReadOnlyList<GridCell> Waypoints)
{
    public static async Task<GridMissionSettings> LoadAsync(string path)
    {
        string json = new UTF8Encoding(false, true).GetString(await File.ReadAllBytesAsync(path));
        if (json.StartsWith('\uFEFF')) json = json[1..];
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;
        Properties(root, "amrId", "start", "waypoints");
        var idValue = root.GetProperty("amrId");
        if (idValue.ValueKind != JsonValueKind.String) throw new ArgumentException("amrId는 문자열이어야 합니다.");
        string id = idValue.GetString()!;
        if (string.IsNullOrWhiteSpace(id) || id.Any(c => char.IsWhiteSpace(c) || char.IsControl(c) || c is '/' or '+' or '#') ||
            Encoding.UTF8.GetByteCount($"amr/{id}/telemetry") > ushort.MaxValue)
            throw new ArgumentException("amrId가 MQTT 식별 기준에 맞지 않습니다.");
        var start = Cell(root.GetProperty("start"));
        var list = root.GetProperty("waypoints");
        if (list.ValueKind != JsonValueKind.Array) throw new ArgumentException("waypoints는 배열이어야 합니다.");
        var waypoints = list.EnumerateArray().Select(Cell).ToArray();
        _ = new GridNavigator(start, waypoints); // 빈 경로·범위·고정 벽을 시작 전에 검사한다.
        return new(id, start, Array.AsReadOnly(waypoints));
    }

    private static GridCell Cell(JsonElement value)
    {
        Properties(value, "row", "col");
        if (value.GetProperty("row").ValueKind != JsonValueKind.Number || value.GetProperty("col").ValueKind != JsonValueKind.Number ||
            !value.GetProperty("row").TryGetInt32(out int row) || !value.GetProperty("col").TryGetInt32(out int col))
            throw new ArgumentException("row·col은 정수여야 합니다.");
        return new(row, col);
    }

    private static void Properties(JsonElement value, params string[] names)
    {
        if (value.ValueKind != JsonValueKind.Object) throw new ArgumentException("설정 항목은 JSON 객체여야 합니다.");
        var found = new HashSet<string>(StringComparer.Ordinal);
        foreach (var property in value.EnumerateObject())
            if (!names.Contains(property.Name, StringComparer.Ordinal) || !found.Add(property.Name))
                throw new ArgumentException("알 수 없거나 중복된 필드: " + property.Name);
        if (found.Count != names.Length) throw new ArgumentException("설정 필수 필드가 누락됐습니다.");
    }
}
